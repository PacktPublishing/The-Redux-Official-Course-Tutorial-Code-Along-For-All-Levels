/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ \"react-redux\");\n/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../store */ \"./store/index.js\");\n/* harmony import */ var _home_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.css */ \"./pages/home.css\");\n/* harmony import */ var _home_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_home_css__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\nfunction App({ Component , pageProps  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_redux__WEBPACK_IMPORTED_MODULE_1__.Provider, {\n        store: _store__WEBPACK_IMPORTED_MODULE_2__[\"default\"],\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"/Users/clarian/Desktop/my-movie-list/pages/_app.tsx\",\n            lineNumber: 14,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/Users/clarian/Desktop/my-movie-list/pages/_app.tsx\",\n        lineNumber: 13,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBdUM7QUFDVjtBQUNUO0FBUXBCLFNBQVNFLElBQUksRUFBRUMsVUFBUyxFQUFFQyxVQUFTLEVBQVksRUFBRTtJQUMvQyxxQkFDRSw4REFBQ0osaURBQVFBO1FBQUNDLE9BQU9BLDhDQUFLQTtrQkFDcEIsNEVBQUNFO1lBQVcsR0FBR0MsU0FBUzs7Ozs7Ozs7Ozs7QUFHOUI7QUFFQSxpRUFBZUYsR0FBR0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL215LW1vdmllLWxpc3QvLi9wYWdlcy9fYXBwLnRzeD8yZmJlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFByb3ZpZGVyIH0gZnJvbSAncmVhY3QtcmVkdXgnO1xuaW1wb3J0IHN0b3JlIGZyb20gJy4uL3N0b3JlJztcbmltcG9ydCAnLi9ob21lLmNzcyc7XG5pbXBvcnQgeyBDb21wb25lbnRUeXBlIH0gZnJvbSAncmVhY3QnO1xuXG5pbnRlcmZhY2UgQXBwUHJvcHMge1xuICBDb21wb25lbnQ6IENvbXBvbmVudFR5cGU8YW55PjtcbiAgcGFnZVByb3BzOiBhbnk7XG59XG5cbmZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH06IEFwcFByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPFByb3ZpZGVyIHN0b3JlPXtzdG9yZX0+XG4gICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgPC9Qcm92aWRlcj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwOyJdLCJuYW1lcyI6WyJQcm92aWRlciIsInN0b3JlIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./store/index.js":
/*!************************!*\
  !*** ./store/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);\n\nconst initialState = {\n    movies: [\n        {\n            title: \"The Godfather\",\n            inBasket: false,\n            liked: false\n        },\n        {\n            title: \"The Shawshank Redemption\",\n            inBasket: false,\n            liked: false\n        },\n        {\n            title: \"The Dark Knight\",\n            inBasket: false,\n            liked: false\n        }\n    ],\n    basket: [],\n    likedMovies: []\n};\nfunction reducer(state = initialState, action) {\n    switch(action.type){\n        case \"ADD_MOVIE\":\n            return {\n                ...state,\n                movies: [\n                    ...state.movies,\n                    action.payload\n                ]\n            };\n        case \"ADD_TO_BASKET\":\n            return {\n                ...state,\n                // it finds the match of the movie and switches it if it is a match\n                movies: state.movies.map((movie)=>movie.title === action.payload ? {\n                        ...movie,\n                        inBasket: !movie.inBasket\n                    } : movie),\n                // if it's already there don't add it otherwise add it\n                basket: state.basket.includes(action.payload) ? state.basket.filter((movie)=>movie !== action.payload) : [\n                    ...state.basket,\n                    action.payload\n                ]\n            };\n        case \"LIKE_MOVIE\":\n            return {\n                ...state,\n                movies: state.movies.map((movie)=>movie.title === action.payload ? {\n                        ...movie,\n                        liked: !movie.liked\n                    } : movie),\n                likedMovies: state.likedMovies.includes(action.payload) ? state.likedMovies.filter((movie)=>movie !== action.payload) : [\n                    ...state.likedMovies,\n                    action.payload\n                ]\n            };\n        default:\n            return state;\n    }\n}\nconst store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({\n    reducer\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (store);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBaUQ7QUFFakQsTUFBTUMsZUFBZTtJQUNqQkMsUUFBUTtRQUNOO1lBQUVDLE9BQU87WUFBaUJDLFVBQVUsS0FBSztZQUFFQyxPQUFPLEtBQUs7UUFBQztRQUN4RDtZQUFFRixPQUFPO1lBQTRCQyxVQUFVLEtBQUs7WUFBRUMsT0FBTyxLQUFLO1FBQUM7UUFDbkU7WUFBRUYsT0FBTztZQUFtQkMsVUFBVSxLQUFLO1lBQUVDLE9BQU8sS0FBSztRQUFDO0tBQzNEO0lBQ0RDLFFBQVEsRUFBRTtJQUNWQyxhQUFhLEVBQUU7QUFDakI7QUFFRixTQUFTQyxRQUFRQyxRQUFRUixZQUFZLEVBQUVTLE1BQU0sRUFBRTtJQUMzQyxPQUFRQSxPQUFPQyxJQUFJO1FBQ2YsS0FBSztZQUNELE9BQU87Z0JBQ0gsR0FBR0YsS0FBSztnQkFDUlAsUUFBUTt1QkFBSU8sTUFBTVAsTUFBTTtvQkFBRVEsT0FBT0UsT0FBTztpQkFBQztZQUM3QztRQUNBLEtBQUs7WUFDRCxPQUFPO2dCQUNMLEdBQUdILEtBQUs7Z0JBQ1IsbUVBQW1FO2dCQUNuRVAsUUFBUU8sTUFBTVAsTUFBTSxDQUFDVyxHQUFHLENBQUNDLENBQUFBLFFBQVNBLE1BQU1YLEtBQUssS0FBS08sT0FBT0UsT0FBTyxHQUFHO3dCQUFFLEdBQUdFLEtBQUs7d0JBQUVWLFVBQVUsQ0FBQ1UsTUFBTVYsUUFBUTtvQkFBQyxJQUFJVSxLQUFLO2dCQUNsSCxzREFBc0Q7Z0JBQ3REUixRQUFRRyxNQUFNSCxNQUFNLENBQUNTLFFBQVEsQ0FBQ0wsT0FBT0UsT0FBTyxJQUFJSCxNQUFNSCxNQUFNLENBQUNVLE1BQU0sQ0FBQ0YsQ0FBQUEsUUFBU0EsVUFBVUosT0FBT0UsT0FBTyxJQUFJO3VCQUFJSCxNQUFNSCxNQUFNO29CQUFFSSxPQUFPRSxPQUFPO2lCQUFDO1lBQzVJO1FBQ0YsS0FBSztZQUNILE9BQU87Z0JBQ0wsR0FBR0gsS0FBSztnQkFDUlAsUUFBUU8sTUFBTVAsTUFBTSxDQUFDVyxHQUFHLENBQUNDLENBQUFBLFFBQVNBLE1BQU1YLEtBQUssS0FBS08sT0FBT0UsT0FBTyxHQUFHO3dCQUFFLEdBQUdFLEtBQUs7d0JBQUVULE9BQU8sQ0FBQ1MsTUFBTVQsS0FBSztvQkFBQyxJQUFJUyxLQUFLO2dCQUM1R1AsYUFBYUUsTUFBTUYsV0FBVyxDQUFDUSxRQUFRLENBQUNMLE9BQU9FLE9BQU8sSUFBSUgsTUFBTUYsV0FBVyxDQUFDUyxNQUFNLENBQUNGLENBQUFBLFFBQVNBLFVBQVVKLE9BQU9FLE9BQU8sSUFBSTt1QkFBSUgsTUFBTUYsV0FBVztvQkFBRUcsT0FBT0UsT0FBTztpQkFBQztZQUNoSztRQUNSO1lBQ0ksT0FBT0g7SUFDZjtBQUNKO0FBRUEsTUFBTVEsUUFBUWpCLGdFQUFjQSxDQUFDO0lBQUVRO0FBQVE7QUFFdkMsaUVBQWVTLEtBQUtBLEVBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1tb3ZpZS1saXN0Ly4vc3RvcmUvaW5kZXguanM/NTZhNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjb25maWd1cmVTdG9yZSB9IGZyb20gJ0ByZWR1eGpzL3Rvb2xraXQnXG5cbmNvbnN0IGluaXRpYWxTdGF0ZSA9IHtcbiAgICBtb3ZpZXM6IFtcbiAgICAgIHsgdGl0bGU6ICdUaGUgR29kZmF0aGVyJywgaW5CYXNrZXQ6IGZhbHNlLCBsaWtlZDogZmFsc2UgfSxcbiAgICAgIHsgdGl0bGU6ICdUaGUgU2hhd3NoYW5rIFJlZGVtcHRpb24nLCBpbkJhc2tldDogZmFsc2UsIGxpa2VkOiBmYWxzZSB9LFxuICAgICAgeyB0aXRsZTogJ1RoZSBEYXJrIEtuaWdodCcsIGluQmFza2V0OiBmYWxzZSwgbGlrZWQ6IGZhbHNlIH0sXG4gICAgXSxcbiAgICBiYXNrZXQ6IFtdLFxuICAgIGxpa2VkTW92aWVzOiBbXVxuICB9XG5cbmZ1bmN0aW9uIHJlZHVjZXIoc3RhdGUgPSBpbml0aWFsU3RhdGUsIGFjdGlvbikge1xuICAgIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcbiAgICAgICAgY2FzZSAnQUREX01PVklFJzpcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICAgICAgbW92aWVzOiBbLi4uc3RhdGUubW92aWVzLCBhY3Rpb24ucGF5bG9hZF1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgJ0FERF9UT19CQVNLRVQnOlxuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgICAgICAgIC8vIGl0IGZpbmRzIHRoZSBtYXRjaCBvZiB0aGUgbW92aWUgYW5kIHN3aXRjaGVzIGl0IGlmIGl0IGlzIGEgbWF0Y2hcbiAgICAgICAgICAgICAgICAgIG1vdmllczogc3RhdGUubW92aWVzLm1hcChtb3ZpZSA9PiBtb3ZpZS50aXRsZSA9PT0gYWN0aW9uLnBheWxvYWQgPyB7IC4uLm1vdmllLCBpbkJhc2tldDogIW1vdmllLmluQmFza2V0IH0gOiBtb3ZpZSksXG4gICAgICAgICAgICAgICAgICAvLyBpZiBpdCdzIGFscmVhZHkgdGhlcmUgZG9uJ3QgYWRkIGl0IG90aGVyd2lzZSBhZGQgaXRcbiAgICAgICAgICAgICAgICAgIGJhc2tldDogc3RhdGUuYmFza2V0LmluY2x1ZGVzKGFjdGlvbi5wYXlsb2FkKSA/IHN0YXRlLmJhc2tldC5maWx0ZXIobW92aWUgPT4gbW92aWUgIT09IGFjdGlvbi5wYXlsb2FkKSA6IFsuLi5zdGF0ZS5iYXNrZXQsIGFjdGlvbi5wYXlsb2FkXVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgY2FzZSAnTElLRV9NT1ZJRSc6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgICAgICAgbW92aWVzOiBzdGF0ZS5tb3ZpZXMubWFwKG1vdmllID0+IG1vdmllLnRpdGxlID09PSBhY3Rpb24ucGF5bG9hZCA/IHsgLi4ubW92aWUsIGxpa2VkOiAhbW92aWUubGlrZWQgfSA6IG1vdmllKSxcbiAgICAgICAgICAgICAgICAgIGxpa2VkTW92aWVzOiBzdGF0ZS5saWtlZE1vdmllcy5pbmNsdWRlcyhhY3Rpb24ucGF5bG9hZCkgPyBzdGF0ZS5saWtlZE1vdmllcy5maWx0ZXIobW92aWUgPT4gbW92aWUgIT09IGFjdGlvbi5wYXlsb2FkKSA6IFsuLi5zdGF0ZS5saWtlZE1vdmllcywgYWN0aW9uLnBheWxvYWRdXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgcmV0dXJuIHN0YXRlXG4gICAgfVxufVxuXG5jb25zdCBzdG9yZSA9IGNvbmZpZ3VyZVN0b3JlKHsgcmVkdWNlciB9KVxuXG5leHBvcnQgZGVmYXVsdCBzdG9yZSJdLCJuYW1lcyI6WyJjb25maWd1cmVTdG9yZSIsImluaXRpYWxTdGF0ZSIsIm1vdmllcyIsInRpdGxlIiwiaW5CYXNrZXQiLCJsaWtlZCIsImJhc2tldCIsImxpa2VkTW92aWVzIiwicmVkdWNlciIsInN0YXRlIiwiYWN0aW9uIiwidHlwZSIsInBheWxvYWQiLCJtYXAiLCJtb3ZpZSIsImluY2x1ZGVzIiwiZmlsdGVyIiwic3RvcmUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./store/index.js\n");

/***/ }),

/***/ "./pages/home.css":
/*!************************!*\
  !*** ./pages/home.css ***!
  \************************/
/***/ (() => {



/***/ }),

/***/ "@reduxjs/toolkit":
/*!***********************************!*\
  !*** external "@reduxjs/toolkit" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();